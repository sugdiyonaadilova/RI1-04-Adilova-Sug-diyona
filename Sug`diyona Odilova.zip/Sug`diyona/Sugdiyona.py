import tkinter as tk

class SampleApp(tk.Tk):
    def __init__(self, *arg, **kwargs):
        tk.Tk.__init__(self, *arg, **kwargs)
        container = tk.Frame(self)
        container.pack(side = "top", fill = "both", expand=True)
        container.grid_rowconfigure(0, weight =1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in(LoginPage, RegPage, BasicPage, BookPage):
            page_name = F.__name__
            frame = F(parent = container, controller = self)
            self.frames[page_name]=frame

            frame.grid(row = 0, column = 0, sticky="nsew")

            self.show_frame("LoginPage")

    def show_frame(self, page_name):
        frame = self.frames[page_name]
        frame.tkraise()

class LoginPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="blue") #color generator for hex
        self.controller = controller
        self.controller.title("ONLINE LIBRARY")
        self.controller.state('zoomed')

        big_lable = tk.Label(self, text = "ONLINE LIBRARY", font = ('Castellar', 50, 'bold'), fg= "black", bg="blue")
        big_lable.pack(pady=30)

        login_lable = tk.Label(self, text = "LOGIN", font = ('Arial', 15, 'bold'), fg= "black", bg="blue")
        login_lable.pack(pady=30)

        my_login = tk.StringVar()
        login_entry = tk.Entry(self, textvariable=my_login, font=('Arial', 15, 'bold'), fg= "black", bg="blue")
        login_entry.pack(pady=30)

        password_lable = tk.Label(self, text="PASSWORD", font=('Arial', 15, 'bold'), fg= "black", bg="blue")
        password_lable.pack()

        my_password = tk.StringVar()
        password_entry = tk.Entry(self, textvariable=my_password, font =('Arial', 15, 'bold'), fg= "black", bg="blue")
        password_entry.pack(pady=30)

        def check_password():
            if my_password.get()=="5555" and my_login.get()=="tiue" or my_password.get()=="2222" and my_login.get()=="menu":
                controller.show_frame('BasicPage')

            else:
                right_lable['text']="Wrong Password or login"

        password_button = tk.Button(self, text="LOG IN", command=check_password, font=('Arial', 15, 'bold'), fg= "black", bg="blue", width='25')
        password_button.pack()
        right_lable = tk.Label(self, font=('Arial', 15, 'bold'), fg= "black", bg="blue")
        right_lable.pack(pady=30)

        def page_registration():
            controller.show_frame('RegPage')
        registration_button = tk.Button(self, text="Create an account", command=page_registration, font=('Arial', 20, 'bold'), fg= "black", bg="blue")
        registration_button.pack(pady=30)

class BasicPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="#64f702")
        self.controller = controller
        big_lable = tk.Label(self, text="WELCOME TO ONLINE LIBRARY", font=('Bernard MT Condensed', 50, 'bold'), fg= "blue", bg="#64f702")
        big_lable.pack(pady=30)

        info_lable = tk.Label(self, text="HOME", font=('Arial', 15, 'bold'), fg="blue", bg="#64f702")
        info_lable.pack(pady=20)
        info_lable.place(x=170, y=200)

        def return_page():
            controller.show_frame('BookPage')
        publisher_button = tk.Button(self, text="PUBLISHERS", command=return_page, font=('Arial', 15, 'bold'), fg="blue", bg="#64f702")
        publisher_button.pack(pady=30)
        publisher_button.place(x=250, y=200)

        pro_lable = tk.Label(self, text="JOURNALS", font=('Arial', 15, 'bold'), fg="blue", bg="#64f702")
        pro_lable.pack(pady=20)
        pro_lable.place(x=410, y=200)

        book_lable = tk.Label(self, text="EBOOKS", font=('Arial', 15, 'bold'), fg="blue", bg="#64f702")
        book_lable.pack(pady=20)
        book_lable.place(x=550, y=200)

        grey_lable = tk.Label(self, text="GREY LITERATURE", font=('Arial', 15, 'bold'), fg="blue", bg="#64f702")
        grey_lable.pack(pady=20)
        grey_lable.place(x=700, y=200)

        contact_lable = tk.Label(self, text="CONTACT", font=('Arial', 15, 'bold'), fg="blue", bg="#64f702")
        contact_lable.pack(pady=20)
        contact_lable.place(x=950, y=200)

        help_lable = tk.Label(self, text="HELP", font=('Arial', 15, 'bold'), fg="blue", bg="#64f702")
        help_lable.pack(pady=20)
        help_lable.place(x=1100, y=200)

        top_lable = tk.Label(self, text="TOP BOOKS", font=('Arial', 15, 'bold'), fg="blue", bg="#64f702")
        top_lable.pack(pady=20)
        top_lable.place(x=500, y=250)

        lectures_lable = tk.Label(self, text="J. R. R. Martin — Game of Thrones", font=('Arial', 15, 'bold'),fg="blue", bg="#64f702")
        lectures_lable.pack(pady=20)
        lectures_lable.place(x=100, y=300)

        pro_lable = tk.Label(self, text="Original description", font=('Arial', 15, 'bold'), fg="blue", bg="#64f702")
        pro_lable.pack(pady=20)
        pro_lable.place(x=100, y=350)

        material_lable = tk.Label(self, text="A Game of Thrones’ is the first novel in A Song of Ice and Fire,", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        material_lable.pack(pady=20)
        material_lable.place(x=50, y=400)

        material_lable = tk.Label(self, text="a series of high fantasy novels by American author George R.", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        material_lable.pack(pady=20)
        material_lable.place(x=50, y=430)

        material_lable = tk.Label(self, text="R. Martin. In the novel, recounting events from various points", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        material_lable.pack(pady=20)
        material_lable.place(x=50, y=460)

        material_lable = tk.Label(self, text="of view, Martin introduces the plot-lines of the noble houses", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        material_lable.pack(pady=20)
        material_lable.place(x=50, y=490)

        material_lable = tk.Label(self, text="of Westeros, the Wall, and the Targaryens. The novel has", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        material_lable.pack(pady=20)
        material_lable.place(x=50, y=520)

        material_lable = tk.Label(self, text="inspired several spin-off works, including several games.", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        material_lable.pack(pady=20)
        material_lable.place(x=50, y=550)

        lectures_lable = tk.Label(self, text="Romeo and Juliet - Shakespeare", font=('Arial', 15, 'bold'),fg="blue", bg="#64f702")
        lectures_lable.pack(pady=20)
        lectures_lable.place(x=800, y=300)

        material_lable = tk.Label(self, text="The well-known story is about the romance of Romeo and", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        material_lable.pack(pady=20)
        material_lable.place(x=700, y=400)

        material_lable = tk.Label(self, text="Juliata, two sons of two families who met during the Italian", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        material_lable.pack(pady=20)
        material_lable.place(x=700, y=430)

        material_lable = tk.Label(self, text="R. Martin. In the novel, recounting events from various points", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        material_lable.pack(pady=20)
        material_lable.place(x=700, y=460)

        material_lable = tk.Label(self, text="Renaissance. This can surprise you if you don’t know the ending.", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        material_lable.pack(pady=20)
        material_lable.place(x=700, y=490)

        def return_page():
            controller.show_frame('LoginPage')
        return_button = tk.Button(self, text="return to main page", command=return_page, font=('Bernard MT Condensed', 15, 'bold'), fg="blue", bg="#64f702")
        return_button.pack(pady=30)
        return_button.place(x=600, y=600)

class RegPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="#07f0d8")
        self.controller = controller

        big_lable = tk.Label(self, text="New User Register", font=('Perpetua Titling MT', 50, 'bold'), fg= "blue", bg="#07f0d8")
        big_lable.pack(pady=30)

        name_lable = tk.Label(self, text="First Name", font=('Arial', 15, 'bold'), fg= "blue", bg="#07f0d8")
        name_lable.pack(pady=20, side='left')
        name_lable.place(x=400, y=170)

        my_name = tk.StringVar()
        name_entry = tk.Entry(self, textvariable=my_name, font=('Arial', 15, 'bold'), fg= "blue", bg="#07f0d8")
        name_entry.pack(pady=20, side='left')
        name_entry.place(x=400, y=210)

        surname_lable = tk.Label(self, text="Last Name", font=('Arial', 15, 'bold'), fg= "blue", bg="#07f0d8")
        surname_lable.pack(pady=20, side='left')
        surname_lable.place(x=400, y=250)

        my_surname = tk.StringVar()
        surname_entry = tk.Entry(self, textvariable=my_surname, font=('Arial', 15, 'bold'), fg= "blue", bg="#07f0d8")
        surname_entry.pack(pady=20, side='left')
        surname_entry.place(x=400, y=290)

        email_lable = tk.Label(self, text="Email adress", font=('Arial', 15, 'bold'), fg= "blue", bg="#07f0d8")
        email_lable.pack(pady=30, side='right')
        email_lable.place(x=800, y=170)

        my_email = tk.StringVar()
        email_entry = tk.Entry(self, textvariable=my_email, font=('Arial', 15, 'bold'), fg= "blue", bg="#07f0d8")
        email_entry.pack(pady=30, side='right')
        email_entry.place(x=800, y=210)

        phone_lable = tk.Label(self, text="Username", font=('Arial', 15, 'bold'), fg= "blue", bg="#07f0d8")
        phone_lable.pack(pady=30, side='right')
        phone_lable.place(x=800, y=250)

        my_phone = tk.StringVar()
        phone_entry = tk.Entry(self, textvariable=my_phone, font=('Arial', 15, 'bold'), fg= "blue", bg="#07f0d8")
        phone_entry.pack(pady=30, side='right')
        phone_entry.place(x=800, y=290)

        login_lable = tk.Label(self, text="Password", font=('Arial', 15, 'bold'), fg= "blue", bg="#07f0d8")
        login_lable.pack(pady=20, side='left')
        login_lable.place(x=400, y=340)

        my_login = tk.StringVar()
        login_entry = tk.Entry(self, textvariable=my_login, font=('Arial', 15, 'bold'), fg= "blue", bg="#07f0d8")
        login_entry.pack(pady=20, side='left')
        login_entry.place(x=400, y=380)

        password_lable = tk.Label(self, text="Mobile Number", font=('Arial', 15, 'bold'), fg= "blue", bg="#07f0d8")
        password_lable.pack(pady=30, side='right')
        password_lable.place(x=800, y=340)

        my_password = tk.StringVar()
        password_entry = tk.Entry(self, textvariable=my_password, font=('Arial', 15, 'bold'), fg= "blue", bg="#07f0d8")
        password_entry.pack(pady=30, side='right')
        password_entry.place(x=800, y=380)

        def my_data():
            if my_login.get()=="" and my_password.get()=="":
                return_data_lable = tk.Label(self, text="Wrong password or login", font=('Arial', 15, 'bold'), fg= "blue", bg="#07f0d8")
                return_data_lable.pack()
                return_data_lable.place(x=600, y=600)
            else:
                return_data_button['text']="Data saved"

        return_data_button = tk.Button(self, text="Register", command=my_data, font=('Arial', 15, 'bold'), fg= "blue", bg="#07f0d8", width='25')
        return_data_button.pack()
        return_data_button.place(x=600, y=500)
        return_data_button = tk.Button(self, font=('Arial', 15, 'bold'), fg= "blue", bg="#07f0d8")
        return_data_button.pack(pady=30)
        return_data_button.place(x=600, y=440)

        def return_page():
            controller.show_frame('BasicPage')
        return_button = tk.Button(self, text="return to main page", command=return_page, font=('Bernard MT Condensed', 15, 'bold'), fg= "blue", bg="#07f0d8")
        return_button.pack(pady=30, side='top')
        return_button.place(x=600, y=550)

class BookPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="yellow")
        self.controller = controller

        big_lable = tk.Label(self, text="Publishing activities:", font=('Perpetua Titling MT', 50, 'bold'), fg= "black", bg="yellow")
        big_lable.pack(pady=30)

        publisher_lable = tk.Label(self, text="DARAKCHI BUSINESS MARKET. NEWSPAPER EDITORIAL", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        publisher_lable.pack(pady=20)
        publisher_lable.place(x=200, y=200)

        publisher_lable = tk.Label(self, text="BRAILLE PRINT", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        publisher_lable.pack(pady=20)
        publisher_lable.place(x=200, y=250)

        publisher_lable = tk.Label(self, text="ADOLAT. CENTER", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        publisher_lable.pack(pady=20)
        publisher_lable.place(x=200, y=300)

        publisher_lable = tk.Label(self, text="AKADEMNASHR LTD.", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        publisher_lable.pack(pady=20)
        publisher_lable.place(x=200, y=350)

        publisher_lable = tk.Label(self, text="ART FLEX BOX LTD.", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        publisher_lable.pack(pady=20)
        publisher_lable.place(x=200, y=400)

        publisher_lable = tk.Label(self, text="BAKTRIA PRESS LTD.", font=('Arial', 15, 'bold'), fg="black", bg="#64f702")
        publisher_lable.pack(pady=20)
        publisher_lable.place(x=200, y=450)

        def return_page():
            controller.show_frame('BasicPage')
        return_button = tk.Button(self, text="return to main page", command=return_page, font=('Bernard MT Condensed', 15, 'bold'), fg="black", bg="yellow")
        return_button.pack(pady=30, side='top')
        return_button.place(x=600, y=600)

if __name__ =="__main__":
    app = SampleApp()
    app.mainloop()

